﻿using System;

namespace Manager
{
	// Token: 0x02000014 RID: 20
	internal class PluginInfo
	{
		// Token: 0x04000073 RID: 115
		public const string GUID = "com.cc_ranger.gorillatag.OS integration manager";

		// Token: 0x04000074 RID: 116
		public const string Name = "OS manager";

		// Token: 0x04000075 RID: 117
		public const string Version = "1.0.0";
	}
}
