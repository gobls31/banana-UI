﻿using System.Text;
using UnityEngine;
using BananaOS;
using Photon.Pun;
using GorillaNetworking;
using System;
using System.Diagnostics.Eventing.Reader;
using System.Diagnostics.Contracts;
using BepInEx.Bootstrap;
using System.Collections.Generic;
using System.Linq;
using BepInEx;
using GorillaComputer.Model;
using HarmonyLib;
using InfoGUI;
using GorillaLocomotion;


namespace BananaOS.Pages
{
    public class ManagerPage : WatchPage
    {
        void Awake()
        {
            MonkeWatch.RegisterPage(typeof(ManagerPage));
        }


        //What will be shown on the main menu if DisplayOnMainMenu is set to true
        public override string Title => "OS integrations";

        //Enabling will display your page on the main menu if you're nesting pages you should set this to false
        public override bool DisplayOnMainMenu => true;
        //important
        string index = "selectionHandler.currentIndex";

        //MOD BOOLS
        public bool speedboost;
        public bool normboost;


        public void Update()
        {
            bool flag = speedboost;
            if (flag)
            {

                GorillaTagger.Instance.handTapVolume = int.MaxValue;

            }
            else 
            {
                GorillaTagger.Instance.handTapVolume = 0.1f;
            }

        }








        //This method will be ran after the watch is completely setup
        public override void OnPostModSetup()
        {
            //max selection index so the indicator stays on the screen
            selectionHandler.maxIndex = 1;


        }

        //What you return is what is drawn to the watch screen the screen will be updated everytime you press a button
        public override string OnGetScreenContent()
        {
            var stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("Integrations");
            /*if (!Enumerable.Any<PluginInfo>(this._plugins))
            {
                stringBuilder.AppendLine(selectionHandler.GetOriginalBananaOSSelectionText(0,"No integrations installed"));
            }
            else
            {
                IEnumerable<PluginInfo> enumerable = Enumerable.Take<PluginInfo>(Enumerable.Skip<PluginInfo>(this._plugins, Mathf.FloorToInt((float)this.pageIndex / (float)this.pageCapacity) * this.pageCapacity), this.pageCapacity);
                int num = this.pageIndex % this.pageCapacity;
                for (int i = 0; i < this.pageCapacity; i++)
                {
                    PluginInfo pluginInfo = Enumerable.Eleme  
                    if (!flag2)
                    {
                        bool flag3 = i == num;
                        stringBuilder.AppendLine(string.Concat(new string[]
                        {
                            pluginInfo.Metadata.Name,
                            ": ",
                            pluginInfo.Instance.enabled ? "<color=lime>E</color>" : "<color=red>D</color>",
                            " ",
                            flag3 ? "<" : ""
                        }));
                    }
                }
                
            }*/
            bool flag = InfoGUI.NotifiLib.hudEnable;
            if (flag)
            {
                stringBuilder.AppendLine(this.selectionHandler.GetOriginalBananaOSSelectionText(0, "Disable Hud"));
            }
            else
            {
                stringBuilder.AppendLine(this.selectionHandler.GetOriginalBananaOSSelectionText(0, "Enable Hud"));
            }
           // bool flag1 = speedboost;
           // if (speedboost)
            //{
              //  stringBuilder.AppendLine(this.selectionHandler.GetOriginalBananaOSSelectionText(1, "Disable Loud Handtaps"));
          //  }
           // else
           //{
              //  stringBuilder.AppendLine(this.selectionHandler.GetOriginalBananaOSSelectionText(1, "Enable Loud Handtaps"));
           // }
            return stringBuilder.ToString();
        }

        public override void OnButtonPressed(WatchButtonType buttonType)
        {

            switch (buttonType)
            {
                case WatchButtonType.Up:
                    selectionHandler.MoveSelectionUp();
                    break;

                case WatchButtonType.Down:
                    selectionHandler.MoveSelectionDown();
                    break;

                case WatchButtonType.Enter:

                    if (selectionHandler.currentIndex == 0)
                    {
                        if (InfoGUI.NotifiLib.hudEnable)
                        {
                            InfoGUI.NotifiLib.hudEnable = false;
                        }
                        else
                        {
                            InfoGUI.NotifiLib.hudEnable = true;

                        }
                    }

                    if (selectionHandler.currentIndex == 1)
                    {
                        if (speedboost)

                        {
                            speedboost = false;

                            Update();
                        }
                        else
                        {
                            speedboost = true;

                            Update();

                        }
                    }

                    break;





                //It is recommended that you keep this unless you're nesting pages if so you should use the SwitchToPage method
                case WatchButtonType.Back:
                    ReturnToMainMenu();
                    break;



            }
        }

        public void ModsFunction()
        {
            IEnumerable<PluginInfo> enumerable = Enumerable.Where<PluginInfo>(Chainloader.PluginInfos.Values, delegate (PluginInfo pi)
            {
                List<string> methodNames = AccessTools.GetMethodNames(pi.Instance);
                return methodNames.Contains("OnEnable") && methodNames.Contains("OnDisable");
            });
            this._plugins = ((enumerable != null && Enumerable.Any<PluginInfo>(enumerable)) ? Enumerable.ToList<PluginInfo>(enumerable) : null);
        }
        public List<PluginInfo> _plugins;

        /*public static bool IsModded()
        {
            return ;
        }*/



         public static void LoudHandTaps()
        {
            GorillaTagger.Instance.handTapVolume = int.MaxValue;
        }

        public static void FixHandTaps()
        {
            GorillaTagger.Instance.handTapVolume = 0.1f;
        }



    }
}
