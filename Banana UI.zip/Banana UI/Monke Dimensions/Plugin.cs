﻿using BananaOS;
using BananaOS.Pages;
using BepInEx;
using System; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Manager;
using BananaOS;
using BepInEx.Bootstrap;
using HarmonyLib;


namespace Plugin

{
    [BepInPlugin(Manager.PluginInfo.GUID, Manager.PluginInfo.Name, Manager.PluginInfo.Version)]
    public class Plugin : BaseUnityPlugin
    {
        public void OnEnable()
        {

        }
        public void OnDisable()
        {

        }
    }

   
}